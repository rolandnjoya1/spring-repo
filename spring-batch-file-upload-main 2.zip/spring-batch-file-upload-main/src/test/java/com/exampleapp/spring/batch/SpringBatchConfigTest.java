package com.exampleapp.spring.batch;
import static org.assertj.core.api.Assertions.assertThat;
import com.exampleapp.spring.batch.config.SpringBatchConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.junit.After;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.batch.test.JobRepositoryTestUtils;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.Nullable;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;


@RunWith(SpringRunner.class)
@SpringBatchTest
@EnableAutoConfiguration
@ContextConfiguration(classes = { SpringBatchConfig.class })
@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public class SpringBatchConfigTest {

    // other test constants
    @Autowired
    @Qualifier("primaryDatasource")
    private HikariDataSource primaryDatasource;
    @Autowired
    @Qualifier("secondaryDatasource")
    private HikariDataSource secondaryDatasource;

    @Autowired
    private JobBuilderFactory jobBuilderFactory;
    @Autowired
    private StepBuilderFactory stepBuilderFactory;
    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    @Autowired
    private JobRepositoryTestUtils jobRepositoryTestUtils;

    @After
    public void cleanUp() {

        jobRepositoryTestUtils.removeJobExecutions();
    }


    private JobParameters defaultJobParameters() {
        JobParametersBuilder paramsBuilder = new JobParametersBuilder();
        paramsBuilder.addString("file.input", null);
        paramsBuilder.addString("file.output", null);
        return paramsBuilder.toJobParameters();
    }

    @Test
    public void launchJob() throws Exception {

        //testing a job
        JobExecution jobExecution = jobLauncherTestUtils.launchJob();
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
        assertThat(jobExecution.getExitStatus().getExitCode()).isEqualTo("COMPLETED");


    }

    @Test
    void getUniqueJobParameters_doesNotRepeatJobParameters() {
        ApplicationContext context = new AnnotationConfigApplicationContext(TestJobConfiguration.class);
        JobLauncherTestUtils testUtils = context.getBean(JobLauncherTestUtils.class);
        Set<JobParameters> jobParametersSeen = new HashSet<>();
        for (int i = 0; i < 10_000; i++) {
            JobParameters jobParameters = testUtils.getUniqueJobParameters();
            assertFalse(jobParametersSeen.contains(jobParameters));
            jobParametersSeen.add(jobParameters);
        }


    }




}

@Configuration
@EnableBatchProcessing
class TestJobConfiguration {

    @Bean
    public Step step(JobRepository jobRepository) {
        return new StepBuilder("step1").tasklet(new Tasklet() {
            @Nullable
            @Override
            public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
                return null;
            }
        }, transactionManager(dataSource())).build();
    }

    @Bean
    public Job job(JobRepository jobRepository) {
        return new JobBuilder("job").flow(step(jobRepository)).end().build();
    }

    @Bean
    public JobLauncherTestUtils testUtils(Job jobUnderTest, JobRepository jobRepository, JobLauncher jobLauncher) {
        JobLauncherTestUtils jobLauncherTestUtils = new JobLauncherTestUtils();
        jobLauncherTestUtils.setJob(jobUnderTest);
        jobLauncherTestUtils.setJobRepository(jobRepository);
        jobLauncherTestUtils.setJobLauncher(jobLauncher);

        return jobLauncherTestUtils;
    }
/*
    @Bean
    public DataSource dataSource() {
    config for database test
    }
*/


}





